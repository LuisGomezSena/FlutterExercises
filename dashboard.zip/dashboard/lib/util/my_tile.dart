import 'package:flutter/material.dart';

class MyTile extends StatelessWidget {
  final int count;

  const MyTile({Key? key, required this.count});

  @override
  Widget build(BuildContext context) {
    return Padding(
        padding: const EdgeInsets.all(8.0),
      child: Container(
        height: 150,
          decoration: BoxDecoration(
          image: DecorationImage(
            alignment: Alignment.centerLeft,
          image: AssetImage("image/img${count +1}.jpg"),
          ),
            borderRadius: BorderRadius.circular(8),
            color: Colors.grey[200]
          ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            TextButton(
              style: ButtonStyle(
                foregroundColor: MaterialStateProperty.all<Color>(Colors.blueAccent),
                alignment: Alignment.bottomRight,
              ),
              onPressed: (){},
              child: const Text("More INFO"),
            ),
            Center(
              child: Column(
              children: [
                // Descripciones de los productos
                if (count == 0)...[
                  Text ("Bugatti Chyron"),Text("523'200.368"),
                  // Product 2
                ]else if (count == 1)...[
                  Text("Bugatti de Competencia"),Text("125'546.546"),
                  // Product 3
                ]else if (count == 2)...[
                  Text("Vehiculo de alto Cilindraje"),Text("325'156.000"),
                  // Product 4
                ]else if (count == 3)...[
                  Text("Nissan 2022"),Text("652'000.999"),
                  // Product 5
                ]else if (count == 4)...[
                  Text("Nissan 2020"),Text("450'000.300"),
                  // Product 6
                ]else if (count == 5)...[
                  Text("LAMBORGHINI 2000"),Text("326'000.000"),
                  // Product 7
                ]else if (count == 6)...[
                  Text("Bugatti 2015"),Text("632'302.000"),
                  // Product 8
                ]else if (count == 7)...[
                  Text("PORCH"),Text("954'203.000"),
                  // Product 9
                ]else if (count == 8)...[
                  Text("BMW 3005"),Text("954'012.000"),
                  // Product 10
                ]else if (count == 9)...[
                  Text("BMW deportivo"),Text("564'300.200"),
                  ],
                ]
              ),
            ),
                ElevatedButton(
                    onPressed:() {},
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.cyanAccent,
                      shape: CircleBorder(),
                      padding: EdgeInsets.all(25),
                    ),
                  child: const Icon(
                      Icons.shopping_cart,
                      color: Colors.black,
                  ),
                ),
              ],
            ),
          ),
        );
      }
    }