import 'package:flutter/material.dart';
import 'lista_productos.dart';

class Carrito extends StatefulWidget {
  final List<ListaProductos> _cart;
  const Carrito(this._cart,  {super.key});

  @override
  State<Carrito> createState() => _CarritoState(this._cart);
}

class _CarritoState extends State<Carrito> {
  _CarritoState(this._cart);

  List<ListaProductos> _cart;

  var deah = 0;
  var deah1 = 0;
  var deah2 = 0;
  var deah3 = 0;
  var deah4 = 0;
  var deah5 = 0;
  var subtotal = 0;

  var subpre = 0;
  var subpre1 = 0;
  var subpre2 = 0;
  var subpre3 = 0;
  var subpre4 = 0;

  var iva = 0;
  var total =0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blueGrey,
      appBar: AppBar(
        backgroundColor: Colors.blue,
        title: const Text(
          'Detalles del producto',
          style: TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 20,
              color: Colors.white
          ),
        ),
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.subdirectory_arrow_left_outlined),
          onPressed: (){
            Navigator.of(context).pop();
            setState(() {
              _cart.length;
            });
          },
          color: Colors.white,
        ),
      ),
      body: GestureDetector(
        child: SingleChildScrollView(
          child: Column(
            children: <Widget>[
              ListView.builder(
                scrollDirection: Axis.vertical,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: _cart.length,
                itemBuilder: (context, index){
                  return Card(
                    elevation: 5,
                    margin: const EdgeInsets.symmetric(
                      horizontal: 10,
                      vertical: 9
                    ),
                    child: Column(
                      children: <Widget>[
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            SizedBox(
                              width: 70,
                              height: 70,
                              child: Image(
                                image: NetworkImage(
                                  _cart[index].imageURL.toString()
                                ),
                                fit: BoxFit.fill,
                              ),
                            ),
                            Expanded(
                              child: Container(
                                padding: const EdgeInsets.only(bottom: 8),
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Padding(
                                      padding: const EdgeInsets.only(
                                        left: 8,
                                        right: 8
                                      ),
                                      child: Center(
                                        child: Text(
                                          _cart[index].nombre.toString(),
                                          style: const TextStyle(
                                            fontSize: 16,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                      ),
                                    )
                                  ],
                                ),
                              ),
                            ),
                            if (index == 0) ...[
                              Row(
                                children: <Widget>[
                                  Column(
                                    children: [
                                      Text('Precio: $subpre        ')
                                    ]
                                  ),
                                  GestureDetector(
                                    child: const Icon(
                                      Icons.remove_circle,
                                      color: Colors.red,
                                    ),
                                    onTap: () {
                                      resta();
                                    },
                                  ),
                                  Padding(
                                    padding:
                                    const EdgeInsets.symmetric(
                                        horizontal: 15.0),
                                    child: Text(
                                      '$deah',
                                      style: const TextStyle(
                                          fontWeight:
                                          FontWeight.bold,
                                          fontSize: 15.0),
                                    ),
                                  ),
                                  GestureDetector(
                                    child: const Icon(
                                      Icons.add_circle,
                                      color: Colors.green,
                                    ),
                                    onTap: () {
                                      suma();
                                    },
                                  ),
                                ],
                              ),
                            ] else if(index == 1)...[
                              Row(
                                children: <Widget>[
                                  Column(
                                      children: [
                                        Text('Precio: $subpre1        ')
                                      ]
                                  ),
                                  GestureDetector(
                                    child: const Icon(
                                      Icons.remove_circle,
                                      color: Colors.red,
                                    ),
                                    onTap: () {
                                      resta1();
                                    },
                                  ),
                                  Padding(
                                    padding:
                                    const EdgeInsets.symmetric(
                                        horizontal: 15.0),
                                    child: Text(
                                      '$deah1',
                                      style: const TextStyle(
                                          fontWeight:
                                          FontWeight.bold,
                                          fontSize: 15.0),
                                    ),
                                  ),
                                  GestureDetector(
                                    child: const Icon(
                                      Icons.add_circle,
                                      color: Colors.green,
                                    ),
                                    onTap: () {
                                      suma1();
                                    },
                                  ),
                                ],
                              ),
                            ] else if(index == 2)...[
                              Row(
                                children: <Widget>[
                                  Column(
                                      children: [
                                        Text('Precio: $subpre2        ')
                                      ]
                                  ),
                                  GestureDetector(
                                    child: const Icon(
                                      Icons.remove_circle,
                                      color: Colors.red,
                                    ),
                                    onTap: () {
                                      resta2();
                                    },
                                  ),
                                  Padding(
                                    padding:
                                    const EdgeInsets.symmetric(
                                        horizontal: 15.0),
                                    child: Text(
                                      '$deah2',
                                      style: const TextStyle(
                                          fontWeight:
                                          FontWeight.bold,
                                          fontSize: 15.0),
                                    ),
                                  ),
                                  GestureDetector(
                                    child: const Icon(
                                      Icons.add_circle,
                                      color: Colors.green,
                                    ),
                                    onTap: () {
                                      suma2();
                                    },
                                  ),
                                ],
                              ),
                            ] else if(index == 3)...[
                              Row(
                                children: <Widget>[
                                  Column(
                                      children: [
                                        Text('Precio: $subpre3        ')
                                      ]
                                  ),
                                  GestureDetector(
                                    child: const Icon(
                                      Icons.remove_circle,
                                      color: Colors.red,
                                    ),
                                    onTap: () {
                                      resta3();
                                    },
                                  ),
                                  Padding(
                                    padding:
                                    const EdgeInsets.symmetric(
                                        horizontal: 15.0),
                                    child: Text(
                                      '$deah3',
                                      style: const TextStyle(
                                          fontWeight:
                                          FontWeight.bold,
                                          fontSize: 15.0),
                                    ),
                                  ),
                                  GestureDetector(
                                    child: const Icon(
                                      Icons.add_circle,
                                      color: Colors.green,
                                    ),
                                    onTap: () {
                                      suma3();
                                    },
                                  ),

                                ],
                              ),
                            ] else if(index == 4)...[
                              Row(
                                children: <Widget>[
                                  Column(
                                      children: [
                                        Text('Precio : $subpre4        ')
                                      ]
                                  ),
                                  GestureDetector(
                                    child: const Icon(
                                      Icons.remove_circle,
                                      color: Colors.red,
                                    ),
                                    onTap: () {
                                      resta4();
                                    },
                                  ),
                                  Padding(
                                    padding:
                                    const EdgeInsets.symmetric(
                                        horizontal: 15.0),
                                    child: Text(
                                      '$deah4',
                                      style: const TextStyle(
                                          fontWeight:
                                          FontWeight.bold,
                                          fontSize: 15.0),
                                    ),
                                  ),
                                  GestureDetector(
                                    child: const Icon(
                                      Icons.add_circle,
                                      color: Colors.green,
                                    ),
                                    onTap: () {
                                      suma4();
                                    },
                                  ),


                                ],
                              ),
                            ] else if(index == 5)...[
                              Row(
                                children: <Widget>[
                                  GestureDetector(
                                    child: const Icon(
                                      Icons.remove_circle,
                                      color: Colors.red,
                                    ),
                                    onTap: () {
                                      resta5();
                                    },
                                  ),
                                  Padding(
                                    padding:
                                    const EdgeInsets.symmetric(
                                        horizontal: 15.0),
                                    child: Text(
                                      '$deah5',
                                      style: const TextStyle(
                                          fontWeight:
                                          FontWeight.bold,
                                          fontSize: 15.0),
                                    ),
                                  ),
                                  GestureDetector(
                                    child: const Icon(
                                      Icons.add_circle,
                                      color: Colors.green,
                                    ),
                                    onTap: () {
                                      suma5();
                                    },
                                  ),
                                  Row(
                                    children: [
                                      Text('PrecioUnit: $subtotal')
                                    ],
                                  )
                                ],
                              ),
                            ],
                          ],
                        ),
                      ],
                    ),
                  );
                },
              ),
              const Divider(
                height: 2,
              ),
              Container(
                width: 500,
                height: 50,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(8),
                  color: Colors.grey[200],
                ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                    'Total: $subtotal',
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      color: Colors.black,
                          ),
                        ),
                      ],
                    )
                  ),
              const Divider(
                height: 2,
              ),
              Container(
                  width: 500,
                  height: 50,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                    color: Colors.grey[200],
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        'IVA: $iva',
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          color: Colors.black,
                        ),
                      ),
                    ],
                  )
                ),
              ],
            ),
          ),
        ),
      );
  }

// Resta//
  void resta() {
    setState(() {
      if (deah != 0) {
        deah = deah - 1;
        subtotal = subtotal - 40000;
        subpre = subpre - 40000;
        iva = (subtotal * 0.19) as int;
        total = subtotal + iva;
      }
    });
  }

  void resta1() {
    setState(() {
      if (deah1 != 0) {
        deah1 = deah1 - 1;
        subtotal = subtotal - 16500;
        subpre1 = subpre1 - 16500;
        iva = (subtotal * 0.19) as int;
        total = subtotal + iva;
      }
    });
  }

  void resta2() {
    setState(() {
      if (deah2 != 0) {
        deah2 = deah2 - 1;
        subtotal = subtotal - 11750;
        subpre2 = subpre2 - 11750;
        iva = (subtotal * 0.19) as int;
        total = subtotal + iva;
      }
    });
  }

  void resta3() {
    setState(() {
      if (deah3 != 0) {
        deah3 = deah3 - 1;
        subtotal = subtotal - 8900;
        subpre3 = subpre3 - 8900;
        iva = (subtotal * 0.19) as int;
        total = subtotal + iva;
      }
    });
  }

  void resta4() {
    setState(() {
      if (deah4 != 0) {
        deah4 = deah4 - 1;
        subtotal = subtotal - 17000;
        subpre4 = subpre4 - 17000;
        iva = (subtotal * 0.19) as int;
        total = subtotal + iva;
      }

    });
  }

  void resta5() {
    setState(() {
      if (deah5 != 0) deah5 = deah5 - 1;
    });
  }

  //SUMA//
  void suma() {
    setState(() {
      deah = deah + 1;
      subtotal = subtotal + 40000;
      subpre = subpre + 40000;
      iva = (subtotal * 0.19) as int;
      total = subtotal + iva;
    });
  }

  void suma1() {
    setState(() {
      deah1 = deah1 + 1;
      subtotal = subtotal + 16500;
      subpre1 = subpre1 + 16500;
      iva = (subtotal * 0.19) as int;
      total = subtotal + iva;
    });
  }

  void suma2() {
    setState(() {
      deah2 = deah2 + 1;
      subtotal = subtotal + 11750;
      subpre2 = subpre2 + 11750;
      iva = (subtotal * 0.19) as int;
      total = subtotal + iva;
    });
  }

  void suma3() {
    setState(() {
      deah3 = deah3 + 1;
      subtotal = subtotal + 8900;
      subpre3 = subpre3 + 8900;
      iva = (subtotal * 0.19) as int;
      total = subtotal + iva;
    });
  }
  void suma4() {
    setState(() {
      deah4 = deah4 + 1;
      subtotal = subtotal + 17000;
      subpre4 = subpre4 + 17000;
      iva = (subtotal * 0.19) as int;
      total = subtotal + iva;
    });
  }

  void suma5() {
    setState(() {
      deah5 = deah5 + 1;
    });
  }

}

