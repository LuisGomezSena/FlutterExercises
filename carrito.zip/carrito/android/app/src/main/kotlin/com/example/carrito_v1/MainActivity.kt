package com.example.carrito_v1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
