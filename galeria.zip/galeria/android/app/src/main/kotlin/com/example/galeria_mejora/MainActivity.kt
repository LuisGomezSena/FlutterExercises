package com.example.galeria_mejora

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
