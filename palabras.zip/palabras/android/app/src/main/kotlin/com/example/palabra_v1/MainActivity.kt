package com.example.palabra_v1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
