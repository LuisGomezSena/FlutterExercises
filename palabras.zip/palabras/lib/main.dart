import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart' show debugPaintSizeEnabled;
import 'presentation/my_app.dart';

void main() {
  runApp(const MyApp());
}
