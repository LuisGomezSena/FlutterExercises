package com.example.login_ui

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
