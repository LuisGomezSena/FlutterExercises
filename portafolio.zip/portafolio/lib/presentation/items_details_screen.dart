import 'package:flutter/material.dart';

class ItemDetailsScreen extends StatelessWidget {
  static const valuekey = ValueKey('ItemDetailScreen');

  final String product;
  final int count;

  const ItemDetailsScreen({Key? key, required this.product, required this.count}) : super(key: key);

  @override
  Widget build (BuildContext context) {
    return Scaffold (
      appBar: AppBar (
        title: const Text("Detalles del Producto"),
        ),
        body: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset("img/img${count + 1}.jpg"),
            Center (
              child: Text(
                product,
                style: Theme.of(context).textTheme.headline2,
              ),
            ),
            // Descripciones de los Vehiculos
            if (product == "Vehiculo 1")...[
              Text ("Bugatti Chyron"),Text("523'200.368"),
              // Product 2
            ]else if (product == "Vehiculo 2")...[
              Text("Bugatti de Competencia"),Text("125'546.546"),
              // Product 3
            ]else if (product == "Vehiculo 3")...[
              Text("Vehiculo de alto Cilindraje"),Text("325'156.000"),
              // Product 4
            ]else if (product == "Vehiculo 4")...[
              Text("Nissan 2022"),Text("652'000.999"),
              // Product 5
            ]else if (product == "Vehiculo 5")...[
              Text("Nissan 2020"),Text("450'000.300"),
              // Product 6
            ]else if (product == "Vehiculo 6")...[
              Text("LAMBORGHINI 2000"),Text("326'000.000"),
              // Product 7
            ]else if (product == "Vehiculo 7")...[
              Text("Bugatti 2015"),Text("632'302.000"),
              // Product 8
            ]else if (product == "Vehiculo 8")...[
              Text("PORCH"),Text("954'203.000"),
              // Product 9
            ]else if (product == "Vehiculo 9")...[
              Text("BMW 3005"),Text("954'012.000"),
              // Product 10
            ]else if (product == "Vehiculo 10")...[
              Text("BMW deportivo"),Text("564'300.200"),
            ],
        ],
      ),
    );
  }
}