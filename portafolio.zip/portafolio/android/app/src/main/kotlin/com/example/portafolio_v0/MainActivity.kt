package com.example.portafolio_v0

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
